from fastapi import FastAPI, UploadFile, File, HTTPException
from core.processor import DentalProcessor
import shutil
import os

app = FastAPI(title="Dental AI API Service")
processor = DentalProcessor()

@app.post("/analyze")
async def analyze_scan(file: UploadFile = File(...)):
    # 临时保存文件
    temp_path = f"temp_{file.filename}"
    with open(temp_path, "wb") as buffer:
        shutil.copyfileobj(file.file, buffer)
    
    try:
        # 处理与分析
        processed = processor.preprocess(temp_path)
        if processed is None:
            raise HTTPException(status_code=400, detail="Invalid image format")
        
        anomalies = processor.find_anomalies(processed)
        
        # 模拟匹配辅助诊断结果
        diagnosis = "Normal" if len(anomalies) < 5 else "Anomaly Detected - Review Required"
        confidence = 0.95 if diagnosis == "Normal" else 0.88
        
        return {
            "filename": file.filename,
            "diagnosis": diagnosis,
            "confidence": confidence,
            "anomalies_count": len(anomalies),
            "requires_human_intervention": confidence < 0.90
        }
    finally:
        if os.path.exists(temp_path):
            os.remove(temp_path)

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
